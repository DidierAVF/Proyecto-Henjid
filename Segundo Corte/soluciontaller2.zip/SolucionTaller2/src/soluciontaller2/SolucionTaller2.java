/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package soluciontaller2;

import java.util.Scanner;

public class SolucionTaller2 {

     public static void main(String[] args) {
        Scanner pe = new Scanner(System.in);

        System.out.println("--------------------------------");
        System.out.println("| Bienvenido Al Programa Banco |");
        System.out.println("--------------------------------");

        System.out.print("Ingrese el numero de cuentas: ");
        int n = pe.nextInt();
        pe.nextLine();

        Cuenta[] cuentas = new Cuenta[n];
        double totalIntereses = 0;
        double totalSaldos = 0;

        for (int i = 0; i < n; i++) {
            System.out.print("Numero de cuenta " + (i + 1) + ": ");
            long numero = pe.nextLong();
            pe.nextLine();

            System.out.print("Fecha de apertura (aaaa/mm/dd): ");
            String fecha = pe.nextLine();

            System.out.println("Tipo de cuenta:");
            System.out.println("1. AhorroDiario");
            System.out.println("2. CuentaJoven");
            System.out.println("3. Tradicional");
            int tipo = pe.nextInt();

            System.out.print("Saldo: ");
            double saldo = pe.nextDouble();

            cuentas[i] = new Cuenta(numero, fecha, tipo, saldo);
        }

        for (int i = 0; i < n; i++) {
            double interes = cuentas[i].calcular_interes();
            double nuevoSaldo = cuentas[i].getSaldo() + interes;

            System.out.println("--------------------------------");
            System.out.println("Cuenta: " + cuentas[i].getNumeroCuenta());
            System.out.println("Interes mensual: " + interes + " $");
            System.out.println("Saldo nuevo: " + nuevoSaldo + " $");

            totalIntereses += interes;
            totalSaldos += nuevoSaldo;
        }

        System.out.println("--------------------------------");
        System.out.println("Valor total de intereses: " + totalIntereses + " $");
        System.out.println("Valor total de saldos: " + totalSaldos + " $");
        System.out.println("--------------------------------");

        pe.close();
    }
}
