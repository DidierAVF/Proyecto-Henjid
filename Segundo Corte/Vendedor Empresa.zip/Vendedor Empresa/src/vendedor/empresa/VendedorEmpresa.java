/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vendedor.empresa;

import java.util.Scanner;

public class VendedorEmpresa {

   public static void main(String[] args) {
        Scanner es = new Scanner(System.in);
        
        System.out.println("---------------------------------------------------");
        System.out.println("| Bienvenido Al Programa De Pago Vendedor Empresa |");
        System.out.println("---------------------------------------------------");
        System.out.println(" ");
        
        System.out.print("Ingrese el documento del vendedor: ");
        String documento = es.nextLine();

        System.out.println("Ingrese el tipo de vendedor: ");
        System.out.println("  1. Puerta a Puerta");
        System.out.println("  2. Telemercado");
        int tipo = es.nextInt();
        
   
        while(tipo!=1 && tipo!=2){
            System.out.println("Numero Invalido eliga una opcion entre 1 y 2");
            System.out.println("");
            System.out.println("Ingrese el tipo de vendedor: ");
            System.out.println("  1. Puerta a Puerta");
            System.out.println("  2. Telemercado");
            tipo = es.nextInt();
         }
       

        System.out.print("Ingrese el valor de las ventas del mes: ");
        double ventas = es.nextDouble();
        
        vendedor v = new vendedor(documento, tipo, ventas);

        System.out.println("\n--- LIQUIDACION DE COMISION ---");
        v.mostrarInfo();

        
        System.out.println(""+v.getDocumento());
        es.close();
    }
}
