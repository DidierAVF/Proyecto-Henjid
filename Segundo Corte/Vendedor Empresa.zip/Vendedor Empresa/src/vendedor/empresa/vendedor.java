/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vendedor.empresa;

/**
 *
 * @author Pc
 */
public class vendedor {
    
    private String documento;
    private int tipoVendedor;
    private double valorVentas;

    public vendedor() {
    }

  
    public vendedor(String documento, int tipoVendedor, double valorVentas) {
        this.documento = documento;
        this.tipoVendedor = tipoVendedor;
        this.valorVentas = valorVentas;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public int getTipovendedor() {
        return tipoVendedor;
    }

    public void setTipovendedor(int tipoVendedor) {
        this.tipoVendedor = tipoVendedor;
    }

    public double getValorVentas() {
        return valorVentas;
    }

    public void setValorVentas(double valorVentas) {
        this.valorVentas = valorVentas;
    }

    public double calcularComision() {
        double comision = 0;
        if (tipoVendedor == 1) {
            comision = valorVentas * 0.25; 
        } else if (tipoVendedor == 2) {
            comision = valorVentas * 0.20;
        } 
        return comision;
    }

    public void mostrarInfo() {
        System.out.println("------------------------------------------");
        System.out.println("Documento: " + documento);
        if(tipoVendedor == 1){
            System.out.println("Tipo de vendedor: Puerta a Puerta");
        }
        else{
            System.out.println("Tipo de vendedor: Telemercadeo");
        }
        System.out.println("Valor de ventas: $" + valorVentas);
        System.out.println("Comision a pagar: $" + calcularComision());
        System.out.println("------------------------------------------");
    }
    
}
