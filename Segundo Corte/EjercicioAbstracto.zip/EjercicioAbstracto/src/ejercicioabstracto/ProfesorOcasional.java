package ejercicioabstracto;

import java.text.NumberFormat;
import java.util.Locale;

public class ProfesorOcasional extends Profesor {
    public ProfesorOcasional() { super(); }

    public ProfesorOcasional(String nombre, String cedula, String nivelEducativo, int horas) {
        super(nombre, cedula, nivelEducativo, "ocasional", horas);
    }

    @Override
    public double calcularSalario() {
        double valorHoraFija = 40000;
        return valorHoraFija * getHoras() * 4; // mensual
    }

    @Override
    public String toString() {
        NumberFormat formatoCOP = NumberFormat.getNumberInstance(new Locale("es", "CO"));
        double valorHora = 40000;
        double salarioMensual = valorHora * getHoras() * 4;

        return "\n--- INFORME DEL PROFESOR OCASIONAL ---\n" +
               super.toString() + "\n" +
               "Nivel educativo: " + getNivelEducativo() + "\n" +
               "Tipo de contrato: Ocasional\n" +
               "Horas semanales: " + getHoras() + "\n" +
               "----------------------------------------\n" +
               "Valor por hora: COP: " + formatoCOP.format(valorHora) + "\n" +
               "Salario mensual: COP: " + formatoCOP.format(salarioMensual) + "\n" +
               "----------------------------------------";
    }
}
