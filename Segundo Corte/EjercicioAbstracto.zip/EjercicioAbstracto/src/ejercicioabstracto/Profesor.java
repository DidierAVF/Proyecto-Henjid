package ejercicioabstracto;

public abstract class Profesor extends Persona {
    private String nivelEducativo;
    private String tipoContrato;
    private int horas;

    public Profesor() {}

    public Profesor(String nombre, String cedula, String nivelEducativo, String tipoContrato, int horas) {
        super(nombre, cedula);
        this.nivelEducativo = nivelEducativo.toLowerCase();
        this.tipoContrato = tipoContrato.toLowerCase();
        this.horas = horas;
    }

    public String getNivelEducativo() { return nivelEducativo; }
    public void setNivelEducativo(String nivelEducativo) { this.nivelEducativo = nivelEducativo.toLowerCase(); }

    public String getTipoContrato() { return tipoContrato; }
    public void setTipoContrato(String tipoContrato) { this.tipoContrato = tipoContrato.toLowerCase(); }

    public int getHoras() { return horas; }
    public void setHoras(int horas) { this.horas = horas; }

    public double obtenerValorHora() {
        switch (nivelEducativo) {
            case "pregrado": return 37000;
            case "especializacion": return 40000;
            case "maestria": return 50000;
            case "doctorado": return 95000;
            default: return 0;
        }
    }
}
