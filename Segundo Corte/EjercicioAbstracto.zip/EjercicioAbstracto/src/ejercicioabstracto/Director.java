package ejercicioabstracto;

import java.text.NumberFormat;
import java.util.Locale;

public class Director extends Persona {
    private final double SALARIO_FIJO = 3160310;

    public Director(String nombre, String cedula) {
        super(nombre, cedula);
    }

    @Override
    public double calcularSalario() {
        return SALARIO_FIJO;
    }

    @Override
    public String toString() {
        NumberFormat formatoCOP = NumberFormat.getNumberInstance(new Locale("es", "CO"));

        return "\n--- INFORME DE DIRECTOR ---\n" +
               super.toString() + "\n" +
               "----------------------------------------\n" +
               "Salario fijo mensual: COP: " + formatoCOP.format(SALARIO_FIJO) + "\n" +
               "----------------------------------------";
    }
}
