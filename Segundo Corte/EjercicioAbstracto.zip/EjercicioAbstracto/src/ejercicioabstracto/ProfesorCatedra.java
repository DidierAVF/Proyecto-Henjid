package ejercicioabstracto;

import java.text.NumberFormat;
import java.util.Locale;

public class ProfesorCatedra extends Profesor {
    public ProfesorCatedra() { super(); }

    public ProfesorCatedra(String nombre, String cedula, String nivelEducativo, int horas) {
        super(nombre, cedula, nivelEducativo, "catedra", horas);
    }

    @Override
    public double calcularSalario() {
        double valorHoraFija = 37000;
        return valorHoraFija * getHoras();
    }

    @Override
    public String toString() {
        NumberFormat formatoCOP = NumberFormat.getNumberInstance(new Locale("es", "CO"));
        double valorHora = 37000;
        double salarioTotal = valorHora * getHoras();

        return "\n--- INFORME DEL PROFESOR DE CATEDRA ---\n" +
               super.toString() + "\n" +
               "Nivel educativo: " + getNivelEducativo() + "\n" +
               "Tipo de contrato: Catedra\n" +
               "Horas dictadas: " + getHoras() + "\n" +
               "----------------------------------------\n" +
               "Valor por hora: COP: " + formatoCOP.format(valorHora) + "\n" +
               "Pago total por horas: COP: " + formatoCOP.format(salarioTotal) + "\n" +
               "----------------------------------------";
    }
}
