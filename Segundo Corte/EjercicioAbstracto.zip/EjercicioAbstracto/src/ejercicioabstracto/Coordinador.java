package ejercicioabstracto;

import java.text.NumberFormat;
import java.util.Locale;

public class Coordinador extends Persona {
    private final double SALARIO_FIJO = 2549233;

    public Coordinador(String nombre, String cedula) {
        super(nombre, cedula);
    }

    @Override
    public double calcularSalario() {
        return SALARIO_FIJO;
    }

    @Override
    public String toString() {
        NumberFormat formatoCOP = NumberFormat.getNumberInstance(new Locale("es", "CO"));

        return "\n--- INFORME DE COORDINADOR ---\n" +
               super.toString() + "\n" +
               "----------------------------------------\n" +
               "Salario fijo mensual: COP: " + formatoCOP.format(SALARIO_FIJO) + "\n" +
               "----------------------------------------";
    }
}
