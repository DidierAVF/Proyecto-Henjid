package ejercicioabstracto;

import java.util.Scanner;

public class EjercicioAbstracto {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Persona persona = null;

        System.out.println("=== CALCULO DE SALARIOS ===");
        System.out.print("Tipo de empleado (profesor / secretaria / coordinador / director): ");
        String tipo = sc.nextLine().trim().toLowerCase();

        switch (tipo) {

            case "profesor":
                System.out.print("Tipo de profesor (planta / ocasional / catedra): ");
                String tipoProf = sc.nextLine().trim().toLowerCase();

                if (!tipoProf.equals("planta") && !tipoProf.equals("ocasional") && !tipoProf.equals("catedra")) {
                    System.out.println("Error: tipo de profesor no valido. Debe ser planta, ocasional o catedra.");
                    sc.close();
                    return;
                }

                System.out.print("Nombre: ");
                String nombre = sc.nextLine();

                System.out.print("Cedula: ");
                String cedula = sc.nextLine();

                System.out.print("Nivel educativo (pregrado / especializacion / maestria / doctorado): ");
                String nivel = sc.nextLine().trim().toLowerCase();

                if (!nivel.equals("pregrado") && !nivel.equals("especializacion") &&
                    !nivel.equals("maestria") && !nivel.equals("doctorado")) {
                    System.out.println("Error: nivel academico no valido. Debe ser pregrado, especializacion, maestria o doctorado.");
                    sc.close();
                    return;
                }

                if (tipoProf.equals("planta")) {
                    persona = new ProfesorPlanta(nombre, cedula, nivel);
                } else {
                    System.out.print("Horas semanales: ");
                    int horas = sc.nextInt();

                    if (horas <= 0) {
                        System.out.println("Error: las horas deben ser mayores que cero.");
                        sc.close();
                        return;
                    }

                    if (tipoProf.equals("ocasional")) {
                        persona = new ProfesorOcasional(nombre, cedula, nivel, horas);
                    } else {
                        persona = new ProfesorCatedra(nombre, cedula, nivel, horas);
                    }
                }
                break;

            case "secretaria":
                System.out.print("Nombre: ");
                String nS = sc.nextLine();

                System.out.print("Cedula: ");
                String cS = sc.nextLine();

                System.out.print("Horas extra: ");
                int horasExtra = sc.nextInt();

                if (horasExtra < 0) {
                    System.out.println("Error: las horas extra no pueden ser negativas.");
                    sc.close();
                    return;
                }

                persona = new Secretaria(nS, cS, horasExtra);
                break;

            case "coordinador":
                System.out.print("Nombre: ");
                String nC = sc.nextLine();

                System.out.print("Cedula: ");
                String cC = sc.nextLine();
                persona = new Coordinador(nC, cC);
                break;

            case "director":
                System.out.print("Nombre: ");
                String nD = sc.nextLine();

                System.out.print("Cedula: ");
                String cD = sc.nextLine();
                persona = new Director(nD, cD);
                break;

            default:
                System.out.println("Error: tipo de empleado no vapprlido. Debe ser profesor, secretaria, coordinador o director.");
                sc.close();
                return;
        }

        // Mostrar resultado final
        if (persona != null) {
            System.out.println("\n--- RESULTADO ---");
            System.out.println(persona.toString());
        }

        sc.close();
    }
}
