package ejercicioabstracto;

import java.text.NumberFormat;
import java.util.Locale;

public class Secretaria extends Persona {
    private int horasExtra;
    private final double SALARIO_MINIMO = 1423500;
    private final double VALOR_HORA_EXTRA = 8000;

    public Secretaria(String nombre, String cedula, int horasExtra) {
        super(nombre, cedula);
        this.horasExtra = horasExtra;
    }

    @Override
    public double calcularSalario() {
        return SALARIO_MINIMO + (horasExtra * VALOR_HORA_EXTRA * 1.5);
    }

    @Override
    public String toString() {
        NumberFormat formatoCOP = NumberFormat.getNumberInstance(new Locale("es", "CO"));
        double pagoHorasExtra = horasExtra * VALOR_HORA_EXTRA * 1.5;
        double total = calcularSalario();

        return "\n--- INFORME DE SECRETARIA ---\n" +
               super.toString() + "\n" +
               "Horas extra: " + horasExtra + "\n" +
               "----------------------------------------\n" +
               "Salario base (SMMLV): COP: " + formatoCOP.format(SALARIO_MINIMO) + "\n" +
               "Pago por horas extra: COP: " + formatoCOP.format(pagoHorasExtra) + "\n" +
               "Salario total: COP: " + formatoCOP.format(total) + "\n" +
               "----------------------------------------";
    }
}
