package ejercicioabstracto;

import java.text.NumberFormat;
import java.util.Locale;

public class ProfesorPlanta extends Profesor {

    public ProfesorPlanta() { super(); }

    public ProfesorPlanta(String nombre, String cedula, String nivelEducativo) {
        super(nombre, cedula, nivelEducativo, "planta", 44);
    }

    @Override
    public double calcularSalario() {
        return obtenerValorHora() * 44 * 4 * 12; // anual
    }

    @Override
    public String toString() {
        NumberFormat formatoCOP = NumberFormat.getNumberInstance(new Locale("es", "CO"));

        double valorHora = obtenerValorHora();
        double salarioMensual = valorHora * 44 * 4;
        double salarioAnual = salarioMensual * 12;

        return "\n--- INFORME DEL PROFESOR DE PLANTA ---\n" +
               super.toString() + "\n" +
               "Nivel educativo: " + getNivelEducativo() + "\n" +
               "Tipo de contrato: Planta\n" +
               "Horas semanales: 44\n" +
               "----------------------------------------\n" +
               "Valor por hora: COP: " + formatoCOP.format(valorHora) + "\n" +
               "Salario mensual: COP: " + formatoCOP.format(salarioMensual) + "\n" +
               "Salario anual: COP: " + formatoCOP.format(salarioAnual) + "\n" +
               "----------------------------------------";
    }
}
