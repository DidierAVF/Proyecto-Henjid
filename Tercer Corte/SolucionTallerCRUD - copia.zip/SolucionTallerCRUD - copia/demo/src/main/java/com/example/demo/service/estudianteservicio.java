package com.example.demo.service;

import com.example.demo.model.estudiante;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class estudianteservicio {
 
    private List<estudiante> estudiantes = new ArrayList<>();

    public estudianteservicio() {
        
        estudiantes.add(new estudiante("Johander Sarmiento", 20, 12));
        estudiantes.add(new estudiante("Didier Vesga", 19 , 20));
        estudiantes.add(new estudiante("Helen", 22 , 21));
    }

    public List<estudiante> listar() {
        return estudiantes;
    }

    
    public estudiante buscarID(int id){
        for (estudiante est : estudiantes) {
            if(est.getId() == id){
                return est;
            }
        }
        return null;
    }

    
    public estudiante insertar(estudiante nuevo_estudiante){
        estudiantes.add(nuevo_estudiante);
        return nuevo_estudiante;
    }

 
    public estudiante actualizar(int id, estudiante datos) {
        estudiante existente = buscarID(id);

        if (existente != null) {
            existente.setNombre(datos.getNombre());
            existente.setEdad(datos.getEdad());
            return existente;
        }
        return null;
    }

    public boolean eliminar(int id) {
        estudiante existente = buscarID(id);
        if (existente != null) {
            estudiantes.remove(existente);
            return true;
        }
        return false;
    }
}