package com.example.demo.controller;

import com.example.demo.model.estudiante;
import com.example.demo.service.estudianteservicio;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/estu")
public class estudiantecontrolador {

    private final estudianteservicio estudianteservicio;
    


    // Constructor de inyeccion
    public estudiantecontrolador(estudianteservicio estudianteservicio) {
        this.estudianteservicio = estudianteservicio;
    }

     //  Actualizar usando PUT
    @PutMapping("/{id}")
    public estudiante actualizar(@PathVariable int id, @RequestBody estudiante datos) { 
        return estudianteservicio.actualizar(id, datos); 
    }

    // Obtener todos los estudiantes - GET
    @GetMapping
    public List<estudiante> listar() { // Retorna List<estudiante>
        return estudianteservicio.listar(); // Llama a estudianteservicio
    }


    // Eliminar usando Delete
    @DeleteMapping("/{id}")
    public String eliminar(@PathVariable int id) {
        boolean eliminado = estudianteservicio.eliminar(id); 
        if (eliminado) {
            return "Estudiante eliminado correctamente.";
        } else {
            return "No se encontró el estudiante con ID " + id;
        }
    }

    // Crear mediante Post 
    @PostMapping
    public estudiante crearEstudiante(@RequestBody estudiante nuevo) { 
        return estudianteservicio.insertar(nuevo); 
    }

    
    // Buscar por ID  Mediante Get / ID
    @GetMapping("/{id}")
    public estudiante buscarPorId(@PathVariable int id) { // Retorna estudiante
        return estudianteservicio.buscarID(id); // Llama a estudianteservicio
    }

   

}