package com.example.demo.repository;

import com.example.demo.model.estudiante;
import org.springframework.data.jpa.repository.JpaRepository;

public interface estudianteRepositorio extends JpaRepository<estudiante, Integer> {

}
