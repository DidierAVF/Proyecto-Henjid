package com.example.demo.service;

import com.example.demo.model.estudiante;
import com.example.demo.repository.estudianteRepositorio;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class estudianteservicio {

    private final estudianteRepositorio repo;

    public estudianteservicio(estudianteRepositorio repo) {
        this.repo = repo;
    }

    public List<estudiante> listar() {
        return repo.findAll();
    }

    public estudiante buscarID(int id) {
        return repo.findById(id).orElse(null);
    }

    public estudiante insertar(estudiante nuevo_estudiante) {
        return repo.save(nuevo_estudiante);
    }

    public estudiante actualizar(int id, estudiante datos) {
        estudiante existente = repo.findById(id).orElse(null);

        if (existente != null) {
            existente.setNombre(datos.getNombre());
            existente.setEdad(datos.getEdad());
            return repo.save(existente);
        }
        return null;
    }

    public boolean eliminar(int id) {
        if (repo.existsById(id)) {
            repo.deleteById(id);
            return true;
        }
        return false;
    }
}
