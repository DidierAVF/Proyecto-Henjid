/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soluciontaller3;

/**
 *
 * @author Pc
 */
public class CuentaCorriente extends Cliente {
    private long numeroCuenta;
    private String fechaApertura;
    private double saldo;
    private double porcentajeInteres;
    private double valorSobregiro;

    public CuentaCorriente(long documento, String nombre, String correo, int celular, String direccion,
                           long numeroCuenta, String fechaApertura, double saldo, double porcentajeInteres, double valorSobregiro) {
        super(documento, nombre, correo, celular, direccion);
        this.numeroCuenta = numeroCuenta;
        this.fechaApertura = fechaApertura;
        this.saldo = saldo;
        this.porcentajeInteres = porcentajeInteres;
        this.valorSobregiro = valorSobregiro;
    }

    public double calcular_interes() {
        return saldo * (porcentajeInteres / 100);
    }

    public long getNumeroCuenta() {
        return numeroCuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public double getValorSobregiro() {
        return valorSobregiro;
    }
}