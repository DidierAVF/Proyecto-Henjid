/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soluciontaller3;

/**
 *
 * @author Pc
 */
public class Cliente {
    private long documento;
    private String nombre;
    private String correo;
    private int celular;
    private String direccion;

    public Cliente(long documento, String nombre, String correo, int celular, String direccion) {
        this.documento = documento;
        this.nombre = nombre;
        this.correo = correo;
        this.celular = celular;
        this.direccion = direccion;
    }

    public long getDocumento() {
        return documento;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public int getCelular() {
        return celular;
    }

    public String getDireccion() {
        return direccion;
    }
}
