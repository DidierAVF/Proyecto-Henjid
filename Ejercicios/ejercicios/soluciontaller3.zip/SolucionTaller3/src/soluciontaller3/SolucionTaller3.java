/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package soluciontaller3;
import java.util.Scanner;
public class SolucionTaller3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner pe = new Scanner(System.in);

        System.out.println("--------------------------------");
        System.out.println("| Sistema de Cuentas del Banco |");
        System.out.println("--------------------------------");

        System.out.println("Ingrese los datos del cliente:");
        System.out.print("Documento: ");
        long documento = pe.nextLong();
        pe.nextLine();

        System.out.print("Nombre: ");
        String nombre = pe.nextLine();

        System.out.print("Correo: ");
        String correo = pe.nextLine();

        System.out.print("Celular: ");
        int celular = pe.nextInt();
        pe.nextLine();

        System.out.print("Direccion: ");
        String direccion = pe.nextLine();

        System.out.println("Seleccione tipo de producto:");
        System.out.println("1. Cuenta de Ahorro");
        System.out.println("2. Cuenta Corriente");
        int opcion = pe.nextInt();

        if (opcion == 1) {
            System.out.print("Numero de cuenta: ");
            long numero = pe.nextLong();
            pe.nextLine();

            System.out.print("Fecha de apertura (aaaa/mm/dd): ");
            String fecha = pe.nextLine();

            System.out.println("Tipo de cuenta:");
            System.out.println("1. AhorroDiario");
            System.out.println("2. CuentaJoven");
            System.out.println("3. Tradicional");
            int tipo = pe.nextInt();

            System.out.print("Saldo: ");
            double saldo = pe.nextDouble();

            Cuenta cuenta = new Cuenta(documento, nombre, correo, celular, direccion, numero, fecha, tipo, saldo);
            double interes = cuenta.calcular_interes();
            double nuevoSaldo = saldo + interes;

            System.out.println("--------------------------------");
            System.out.println("Cliente: " + cuenta.getNombre());
            System.out.println("Cuenta: " + cuenta.getNumeroCuenta());
            System.out.println("Interes mensual: " + interes + " $");
            System.out.println("Saldo nuevo: " + nuevoSaldo + " $");

        } else if (opcion == 2) {
            System.out.print("Numero de cuenta: ");
            long numero = pe.nextLong();
            pe.nextLine();

            System.out.print("Fecha de apertura (aaaa/mm/dd): ");
            String fecha = pe.nextLine();

            System.out.print("Saldo: ");
            double saldo = pe.nextDouble();

            System.out.print("Porcentaje de interes mensual (%): ");
            double porcentaje = pe.nextDouble();

            System.out.print("Valor permitido de sobregiro: ");
            double sobregiro = pe.nextDouble();

            CuentaCorriente cc = new CuentaCorriente(documento, nombre, correo, celular, direccion, numero, fecha, saldo, porcentaje, sobregiro);
            double interes = cc.calcular_interes();
            double nuevoSaldo = saldo + interes;

            System.out.println("--------------------------------");
            System.out.println("Cliente: " + cc.getNombre());
            System.out.println("Cuenta Corriente: " + cc.getNumeroCuenta());
            System.out.println("Interes mensual: " + interes + " $");
            System.out.println("Saldo nuevo: " + nuevoSaldo + " $");
            System.out.println("Valor permitido de sobregiro: " + cc.getValorSobregiro() + " $");
        }

        pe.close();
    }
    
}
