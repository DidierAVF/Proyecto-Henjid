/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soluciontaller3;

/**
 *
 * @author Pc
 */

public class Cuenta extends Cliente {
    private long numeroCuenta;
    private String fechaApertura;
    private int tipoCuenta;
    private double saldo;

    public Cuenta(long documento, String nombre, String correo, int celular, String direccion,
                  long numeroCuenta, String fechaApertura, int tipoCuenta, double saldo) {
        super(documento, nombre, correo, celular, direccion);
        this.numeroCuenta = numeroCuenta;
        this.fechaApertura = fechaApertura;
        this.tipoCuenta = tipoCuenta;
        this.saldo = saldo;
    }

    public long getNumeroCuenta() {
        return numeroCuenta;
    }

    public String getFechaApertura() {
        return fechaApertura;
    }

    public int getTipoCuenta() {
        return tipoCuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public double calcular_interes() {
        double interes = 0;
        if (tipoCuenta == 1) {
            interes = saldo * 0.015;
        } else if (tipoCuenta == 2) {
            interes = saldo * 0.017;
        } else if (tipoCuenta == 3) {
            interes = saldo * 0.016;
        }
        return interes;
    }
}