package com.mycompany.soluciontaller1;

import java.util.Scanner;

public class SolucionTaller1 {

    public static void main(String[] args) {

        Scanner pe = new Scanner(System.in);

        System.out.println("--------------------------------");
        System.out.println("| Bienvenido Al Programa Banco |");
        System.out.println("--------------------------------");

        System.out.println("Ingrese Numeros de cuentas: ");
        int n = pe.nextInt();

        long[] numero_cuenta = new long[n];
        String[] fecha = new String[n];
        int[] tipo_cuenta = new int[n];
        double[] saldo = new double[n];
        double[] interes = new double[n];

        double total_intereses = 0;
        double total_saldos = 0;

        for (int i = 0; i < n; i++) {
            System.out.print("Ingrese su numero de cuenta"+(i+1)+" :");
            numero_cuenta[i] = pe.nextLong();
            pe.nextLine();

            System.out.print("Ingrese fecha de apertura (aaaa/mm/dd)"+(i+1)+" :");
            fecha[i] = pe.nextLine();

            while (fecha[i].length() != 10) {
                System.out.print("Longitud de fecha no valida, intente de nuevo: ");
                fecha[i] = pe.nextLine();
            }

            System.out.println("Ingrese El tipo de cuenta"+(i+1)+" :");
            System.out.println("1. AhorroDiario");
            System.out.println("2. CuentaJoven");
            System.out.println("3. Tradicional");
            tipo_cuenta[i] = pe.nextInt();

            while (tipo_cuenta[i] != 1 && tipo_cuenta[i] != 2 && tipo_cuenta[i] != 3) {
                System.out.println("Numero Invalido eliga una opcion entre 1,2 y 3");
                System.out.println("");
                System.out.println("Ingrese El tipo de cuenta"+(i+1)+" :");
                System.out.println("1. AhorroDiario");
                System.out.println("2. CuentaJoven");
                System.out.println("3. Tradicional");
                tipo_cuenta[i] = pe.nextInt();
            }

            System.out.println("Ingrese el saldo de la cuenta:"+(i+1)+" :");
            saldo[i] = pe.nextDouble();
        }

        for (int i = 0; i < n; i++) {
            System.out.println("--------------------------------");
            System.out.println("Numero de cuenta:" +(i+1)+" :"+ numero_cuenta[i]);

            if (tipo_cuenta[i] == 1) {
                interes[i] = saldo[i] * 0.015;
            } else if (tipo_cuenta[i] == 2) {
                interes[i] = saldo[i] * 0.017;
            } else {
                interes[i] = saldo[i] * 0.016;
            }

            System.out.println("Su interes es"+(i+1)+" :" + interes[i] + " $");

            saldo[i] = saldo[i] + interes[i];

            System.out.println("Saldo de la cuenta con el interes"+(i+1)+" :"+ saldo[i] + " $");

            total_intereses += interes[i];
            total_saldos += saldo[i];
        }

        System.out.println("--------------------------------");
        System.out.println("Valor total de intereses: " + total_intereses + " $");
        System.out.println("Valor total de saldos: " + total_saldos + " $");
        System.out.println("--------------------------------");

        pe.close();
    }
}
